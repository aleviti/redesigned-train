package it.uniroma3.repository;

import it.uniroma3.model.Studente;
import org.springframework.data.repository.CrudRepository;



public interface StudenteRepository extends CrudRepository<Studente, Long> {


		
}
