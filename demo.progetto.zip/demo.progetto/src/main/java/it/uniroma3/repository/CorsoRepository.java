package it.uniroma3.repository;

import it.uniroma3.model.Corso;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface CorsoRepository extends CrudRepository<Corso, Long> {

	public List<Corso> findByOrario(String orario);

	

	
	

	
	
	

	
}
